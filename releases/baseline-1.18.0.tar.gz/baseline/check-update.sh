#!/bin/sh
set -e
MANIFEST_URL="https://firmware.yourbaselinehome.com/manifest.json"
LOCAL_VERSION_FILE="/config/baseline/current_version"
CONFIG_DIR="/config"
LOG_FILE="/config/baseline/update.log"
mkdir -p /config/baseline
log() { echo "$(date): $1" >> "$LOG_FILE"; }
log "=== Starting update check ==="
REMOTE_MANIFEST=$(curl -s --fail --max-time 30 "$MANIFEST_URL") || { log "ERROR: Failed to fetch manifest"; exit 1; }
REMOTE_VERSION=$(echo "$REMOTE_MANIFEST" | jq -r ".version")
FIRMWARE_URL=$(echo "$REMOTE_MANIFEST" | jq -r ".firmware_url")
CHECKSUM=$(echo "$REMOTE_MANIFEST" | jq -r ".checksum_sha256")
LOCAL_VERSION=$(cat "$LOCAL_VERSION_FILE" 2>/dev/null || echo "0.0.0")
log "Local: $LOCAL_VERSION Remote: $REMOTE_VERSION"
if [ "$REMOTE_VERSION" = "$LOCAL_VERSION" ]; then log "Already up to date"; exit 0; fi
log "Downloading update..."
curl -s --fail --max-time 120 -o /tmp/update.tar.gz "$FIRMWARE_URL" || { log "ERROR: Download failed"; exit 1; }
if [ -n "$CHECKSUM" ] && [ "$CHECKSUM" != "null" ]; then
  ACTUAL=$(sha256sum /tmp/update.tar.gz | cut -d" " -f1)
  if [ "$ACTUAL" != "$CHECKSUM" ]; then log "ERROR: Checksum mismatch"; rm /tmp/update.tar.gz; exit 1; fi
  log "Checksum OK"
fi
rm -rf /tmp/baseline-update
mkdir -p /tmp/baseline-update
tar -xzf /tmp/update.tar.gz -C /tmp/baseline-update
log "Applying update..."
for file in configuration.yaml automations.yaml scripts.yaml customize.yaml; do
  if [ -f "/tmp/baseline-update/$file" ]; then
    cp "/tmp/baseline-update/$file" "$CONFIG_DIR/$file"
    log "Updated: $file"
  fi
done
if [ -f "/tmp/baseline-update/baseline/check-update.sh" ]; then
  cp "/tmp/baseline-update/baseline/check-update.sh" /config/baseline/check-update.sh
  chmod +x /config/baseline/check-update.sh
fi
echo "$REMOTE_VERSION" > "$LOCAL_VERSION_FILE"
rm -rf /tmp/update.tar.gz /tmp/baseline-update
log "Update complete: $REMOTE_VERSION"
curl -s -X POST http://supervisor/core/restart -H "Authorization: Bearer $SUPERVISOR_TOKEN" 2>/dev/null || log "Restart API failed"
log "=== Done ==="
